<?php
    header("Content-Type: application/json; charset=utf-8");
    header("x-api-key: ".$api_key);
?>